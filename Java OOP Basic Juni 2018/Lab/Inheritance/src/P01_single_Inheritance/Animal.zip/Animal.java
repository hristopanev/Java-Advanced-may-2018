package P01_single_Inheritance;

public class Animal {
    public void eat(){
        System.out.println("eating...");
    }
}
