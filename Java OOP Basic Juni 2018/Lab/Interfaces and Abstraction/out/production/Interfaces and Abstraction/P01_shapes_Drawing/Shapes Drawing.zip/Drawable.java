package P01_shapes_Drawing;

public interface Drawable {

    void draw();
}
