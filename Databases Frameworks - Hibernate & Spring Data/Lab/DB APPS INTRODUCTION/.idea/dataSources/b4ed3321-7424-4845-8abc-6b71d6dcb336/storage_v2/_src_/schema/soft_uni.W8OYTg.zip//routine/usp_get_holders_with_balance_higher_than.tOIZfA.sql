create procedure usp_get_holders_with_balance_higher_than(IN min_balance decimal(19, 4))
  BEGIN 
	SELECT
		ac_h.first_name,
		ac_h.last_name
		FROM account_holders AS ac_h
		JOIN accounts AS ac
        ON ac_h.id = ac.account_holder_id
        GROUP BY ac_h.id
        HAVING SUM(ac.balance) > min_balance
        ORDER BY  ac.id ASC;
END;

