create procedure usp_get_towns_starting_with(IN input_alph varchar(20))
  BEGIN
	SELECT
		t.name
	FROM towns AS t
    WHERE LEFT(name, LENGTH(input_alph)) LIKE (input_alph)
    ORDER BY t.name;
END;

