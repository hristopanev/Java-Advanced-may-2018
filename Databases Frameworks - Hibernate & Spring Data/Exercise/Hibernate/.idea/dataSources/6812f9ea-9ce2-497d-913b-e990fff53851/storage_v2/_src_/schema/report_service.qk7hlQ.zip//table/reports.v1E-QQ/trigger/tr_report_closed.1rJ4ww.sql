create trigger tr_report_closed
  before UPDATE
  on reports
  for each row
  BEGIN
    IF (ISNULL(OLD.close_date) <> ISNULL(NEW.close_date)) THEN
        SET NEW.status_id = 3;
    END IF;
END;

