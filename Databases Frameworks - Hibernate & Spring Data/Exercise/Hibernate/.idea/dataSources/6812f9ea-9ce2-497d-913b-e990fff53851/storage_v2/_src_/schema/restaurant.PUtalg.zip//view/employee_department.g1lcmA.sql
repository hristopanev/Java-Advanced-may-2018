create view employee_department as
  select `e`.`first_name`    AS `first_name`,
         `e`.`last_name`     AS `last_name`,
         `e`.`department_id` AS `department_id`,
         `d`.`name`          AS `name`
  from (`restaurant`.`employees` `e` join `restaurant`.`departments` `d` on ((`e`.`department_id` = `d`.`id`)));

