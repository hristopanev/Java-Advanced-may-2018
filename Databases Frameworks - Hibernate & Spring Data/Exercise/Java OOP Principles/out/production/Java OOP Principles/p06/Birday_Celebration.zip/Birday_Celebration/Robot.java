package p06.Birday_Celebration;

public class Robot extends Identifiable {
    private String model;

    public Robot(String model, String id) {
        super(id);
        this.model = model;
    }
}
