package p06.Birday_Celebration;

public interface Birthable {

    String getBirthdate();

    boolean isBornIn(String year);
}
