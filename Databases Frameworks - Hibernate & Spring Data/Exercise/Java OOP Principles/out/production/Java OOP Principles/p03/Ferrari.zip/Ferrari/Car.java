package p03.Ferrari;


public interface Car {

    String getBrand();
    String getModel();
    String getDriver();
    String getStart();
    String getStop();
}
