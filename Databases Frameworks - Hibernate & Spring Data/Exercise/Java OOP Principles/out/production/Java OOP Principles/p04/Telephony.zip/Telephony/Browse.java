package p04.Telephony;

import java.util.Collection;

public interface Browse {

    String Browsing(String site);
}
