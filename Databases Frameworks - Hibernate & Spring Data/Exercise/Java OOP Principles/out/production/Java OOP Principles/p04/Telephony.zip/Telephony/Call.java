package p04.Telephony;

import java.util.Collection;

public interface Call {

    String Calling(String phone);

}
