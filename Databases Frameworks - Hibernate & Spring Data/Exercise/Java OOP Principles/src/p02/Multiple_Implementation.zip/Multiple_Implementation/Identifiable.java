package p02.Multiple_Implementation;

public interface Identifiable {

    String getId();
}
