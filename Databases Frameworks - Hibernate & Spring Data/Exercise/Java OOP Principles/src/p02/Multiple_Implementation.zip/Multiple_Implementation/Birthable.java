package p02.Multiple_Implementation;

public interface Birthable {

    String getBirthdate();
}
