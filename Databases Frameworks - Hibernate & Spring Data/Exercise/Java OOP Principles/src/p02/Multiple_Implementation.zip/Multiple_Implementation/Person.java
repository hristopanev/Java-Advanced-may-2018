package p02.Multiple_Implementation;

public interface Person {
    String getName();
    int getAge();


}
