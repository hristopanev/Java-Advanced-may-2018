package p01.Define_an_Interface_Person;

public interface Person {
    String getName();
    int getAge();


}
