package model;

public interface Model {
    String getModel();
}
