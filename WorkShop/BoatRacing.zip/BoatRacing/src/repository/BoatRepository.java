package repository;

import model.boat.Boat;

public class BoatRepository extends BaseRepository<Boat> {

}
