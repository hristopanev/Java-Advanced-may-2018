package repository;

import model.engine.Engine;


public class EngineRepository extends BaseRepository<Engine> {

}
