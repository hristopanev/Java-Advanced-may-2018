package exceptions;

public class InsufficientContestantsException extends Exception {
}
