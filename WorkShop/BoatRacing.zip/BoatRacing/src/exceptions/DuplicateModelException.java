package exceptions;

public class DuplicateModelException extends Exception {
}
