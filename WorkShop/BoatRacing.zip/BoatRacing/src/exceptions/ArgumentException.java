package exceptions;

public class ArgumentException extends Exception {
}
