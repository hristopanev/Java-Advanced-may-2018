package exceptions;

public class RaceAlreadyExistsException extends Exception {
}
