package exceptions;

public class NoSetRaceException extends Exception {
}
