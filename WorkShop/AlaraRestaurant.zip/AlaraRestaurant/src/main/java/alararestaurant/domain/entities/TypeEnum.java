package alararestaurant.domain.entities;

public enum  TypeEnum {

    ForHere, ToGo;
}
