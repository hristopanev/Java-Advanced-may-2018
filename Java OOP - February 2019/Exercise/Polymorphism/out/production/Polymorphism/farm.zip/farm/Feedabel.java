package farm;

public interface Feedabel {

    void eat(Food food);
}
