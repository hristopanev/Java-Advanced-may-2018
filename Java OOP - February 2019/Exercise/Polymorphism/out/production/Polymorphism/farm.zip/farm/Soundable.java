package farm;

public interface Soundable {
    String  makeSound();
}
