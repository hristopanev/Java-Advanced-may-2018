package telephony;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//
//        String[] numbers = scanner.nextLine().split("\\s+");
//        String[] urls = scanner.nextLine().split("\\s+");
//
//        Smartphone smartphone = new Smartphone();
//
//        for (String number : numbers) {
//            try {
//                smartphone.call(number);
//        }catch (IllegalArgumentException ex){
//                System.out.println(ex.getMessage());
//            }
//
//        }
//
//        for (String url : urls) {
//            try {
//                smartphone.browse(url);
//            }catch (IllegalArgumentException ex){
//                System.out.println(ex.getMessage());
//            }
//        }
    }
}
