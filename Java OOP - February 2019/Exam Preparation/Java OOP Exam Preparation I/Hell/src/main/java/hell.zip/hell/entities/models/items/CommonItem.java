package hell.entities.models.items;

public class CommonItem extends BaseItem {
    public CommonItem(String  nameBonus, int strengthBonus, int agilityBonus, int intelligenceBonus, int hitPointsBonus, int damageBonus) {
        super(nameBonus, strengthBonus, agilityBonus, intelligenceBonus, hitPointsBonus, damageBonus);
    }
}
